<?php
  $settings['dbtype']="mysql";
  $settings['dbname']="casetracker";
  $settings['dbhost']="localhost";
  $settings['dbuser']="root";
  $settings['dbpass']="";
  $settings['dbprefix']="flyspray_";
  
  $settings['externaldb']=true;
  $settings['externaldbname']="oms";
  
?>
