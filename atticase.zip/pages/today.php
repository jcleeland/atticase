<?php
  
?>
A case<br />
Some other case<br />
etc
