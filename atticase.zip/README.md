# opencasetracker
 OpenCaseTracker
A web based tool for industrial case management
