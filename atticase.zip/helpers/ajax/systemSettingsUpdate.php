<?php
    $tablename="prefs";
    $output=$oct->updateTable($tablename, $_POST['values'], $_POST['wheres'], null, 0);
    
?>
